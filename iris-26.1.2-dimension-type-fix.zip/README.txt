Iris 26.1.2 dimension type compatibility fix

Use this only if Paper/Folia 26.1.2 fails with:
No key has_ender_dragon_fight in dimension_type iris:aiamgajach8.

Install:
1. Stop the server.
2. Copy this whole iris-26.1.2-dimension-type-fix folder into world/datapacks/.
3. Make sure the server also still has the original Iris datapack.
4. Start the server.

This overrides the generated Iris overworld dimension type and adds:
"has_ender_dragon_fight": false

If Iris regenerates a different dimension type id, add the same field to the new
world/datapacks/iris/data/iris/dimension_type/<id>.json file instead.
